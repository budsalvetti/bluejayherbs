IMPORTANT!!

FOR YOUR INSTALLATION AND EXPANSION TO WORK PROPERLY, YOUR MIMIC MUST HAVE THE LATEST OS UPDATE (currently v1.0.8) AND LIBRARY/REFERENCE TOM UPDATE IMPLEMENTED BEFORE YOU BEGIN!!

UPDATES ARE AVAILABLE HERE: http://pearldrum.com/products/kits/electronics/mimic-pro-module/#updates

-----

UPDATE NOTES:

Hi V Expressions Ltd family!

Your Professional kits are designed on and for Mimic OS 1.0.8 or later. The kits WILL NOT work/load on previous Mimic OS versions, and may cause issues during an attempt to load. It is imperative that you follow our complete module setup instructions in the included expansion's Owner's Manual. 

As always, please backup your current kits and all data before beginning. Once you have created your backups, please continue with our instructions to load your new expansion kits and or instruments. You can find all these instructions in your included manual.

Thank you for being part of the V Expressions Ltd family!

Alan Miller
V Expressions Ltd
www.vexpressionsltd.com
